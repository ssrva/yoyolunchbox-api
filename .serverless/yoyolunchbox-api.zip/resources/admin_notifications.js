const { dbClient } = require("./database-client")

const client = dbClient()

module.exports.addNotification = async (event) => {
  const { type, metadata } = JSON.parse(event.body)
  const addNotificationQuery = `
    INSERT INTO admin_notifications (notification_type, metadata)
    VALUES ('${type}', '${metadata}')
  `
  const response = await client.query(addNotificationQuery)
  return response
}